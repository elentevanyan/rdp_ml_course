Продолжаем вводиться в python и знакомимся с pandas
=====

## Материалы с семинара:

* [Скачать папку полностью](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/FUlyankin/Intro_to_DS/tree/master/sem02)
* Настал момент, когда пора скачать [табличные данные](https://github.com/FUlyankin/Intro_to_DS/tree/master/data). Алгоритм такой: [скачиваете папку полностью](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/FUlyankin/Intro_to_DS/tree/master/data), распаковываете её там же, где распаковываете семинары по курсу, запускать ничего не нужно.
